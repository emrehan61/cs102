
P5. Activity Summarizer for Personal Time Management

G3N Members: Beyza Çağlar, Emrehan Hoşver, Tuna Okçu

Activity Summarizer is a program that is developed in order to help the user manage their time 
more efficiently by summarizing their activities. The program can produce a daily, weekly or
monthly report for the user according to the activities they have done during a period of time . 
However, the user must specify the date and the duration of an activity while creating a new
entry since the summaries are based solely on the data entered by the user.

The program currently works locally. In order to setup, recompile, and run the program one simply 
needs to run the file called App.java.

As for tools, we used version 1.55.2 of the VSCode code editor.


DISCLAIMER: 
We have worked on the project together with the help of some program extensions. As a result, we 
had theopportunity to help each other while working on the implementation of the program, therefore,
the following distribution of tasks is not entirely true as it is difficult to divide up our work 
into distinct parts.

Beyza Çağlar: implementation of the Summary and Entry class, GUI
Emrehan Hoşver: implementation of the User class, GUI
Tuna Okçu : implementation of the ActivityType class(also helped with other class implementations )


package MAIN;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import Buttons.*;
import java.time.LocalDate;


public class Screen extends JFrame implements ActionListener{
    private User userx;
    private JMenuBar menu;
    private JMenu setting;
    private JMenu help;
    private JMenu profile;
    private JMenu tdlist;
    private JMenu summary;
    private JMenuItem summarize;
  
    private JMenuItem lang;
    private JMenuItem theme;
    private Gbut addent;
    
    public Screen(User x){ 
        
        userx = x;
        setTitle(userx.getName() +"   "  +LocalDate.now());
        
        setSize(800, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(new Color(51,204,255));
        
        menu = new JMenuBar();
        
         setting = new JMenu("Settings");
        setting.setFont((new Font("Serif", Font.BOLD | Font.ITALIC, 18)));
        setting.setBackground(new Color(51,204,255));
        setting.setForeground(new Color(0, 0, 0));
        
         help = new JMenu("Help");
        help.setFont((new Font("Serif", Font.BOLD | Font.ITALIC, 18)));
        help.setBackground(new Color(51,204,255));
        help.setForeground(new Color(0, 0, 0));
        
         profile = new JMenu("Profile");
        profile.setFont((new Font("Serif", Font.BOLD | Font.ITALIC, 18)));
        profile.setBackground(new Color(51,204,255));
        profile.setForeground(new Color(0, 0, 0));
        
         tdlist = new JMenu("To-Do List");
        tdlist.setFont((new Font("Serif", Font.BOLD | Font.ITALIC, 18)));
        tdlist.setBackground(new Color(51,204,255));
        tdlist.setForeground(new Color(0, 0, 0));
        
         summary = new JMenu("Summarize");
        summary.setFont((new Font("Serif", Font.BOLD | Font.ITALIC, 18)));
        summary.setBackground(new Color(51,204,255));
        summary.setForeground(new Color(0, 0, 0));
        //summary.addActionListener(this);
        menu.setBackground(new Color(51,204,255));
        
        summarize = new JMenuItem ("Check Summary");
         lang = new JMenuItem("Language");
         theme = new JMenuItem("Theme");
        summary.add(summarize);
        summarize.addActionListener(this);
        setting.add(lang);
        setting.add(theme);
        
        
        
        menu.add(setting);
        menu.add(help);
        menu.add(profile);
        menu.add(tdlist);
        menu.add(summary);
        this.setJMenuBar(menu);
        
        addent = new Gbut("Add Entry");
        this.add(addent);
        addent.addActionListener(new ActionListener(){
            
            @Override
	        public void actionPerformed(ActionEvent e) {
                
                Frr abc = new Frr (userx) ;
		
	}
            });
        
        this.setVisible(true);
    }
    
    
	@Override
	public void actionPerformed(ActionEvent e) {
        if(e.getSource() == summarize){
            
            AskForDate summed = new AskForDate(userx);
            summed.run();
            
        }
        
		
	}
}


import comClasses.*;
import java.io.*;


public class App   {
    
    /** 
     * @param args
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {
        
        /**ArrayList<User> users = new ArrayList<>();
        
        System.out.println("Hello, World!");
        JFrame frame1 = new JFrame("Activity Summarizer");
        frame1.setSize(800, 500);
        frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame1.getContentPane().setBackground(new Color(51,204,255));
       // frame1.setLayout(new BorderLayout());
        
       JPanel panel1 = new JPanel();
        panel1.setBackground(new Color(51,204,255));
        panel1.setLayout(new FlowLayout());
        
        Gbut but1 = new Gbut("Add User");
        Gbut but2 = new Gbut("Choose User");
        
        JLabel welcome = new JLabel("Welcome to Activity Summarizer", JLabel.CENTER);
        welcome.setFont(new Font("Serif", Font.BOLD | Font.ITALIC, 30));
         welcome.setForeground(new Color(255,255,255));
        
        //JComboBox userselect = new JComboBox<User>(users.toArray());
         
         
        panel1.setPreferredSize(new Dimension (50,200));
        frame1.add(welcome);
        panel1.add(but1);
        panel1.add(but2);
       // panel1.add(userselect);
        frame1.add( panel1 , BorderLayout.SOUTH);
        
       
        
        frame1.setVisible(true);
        
    }*/
       
       Start start1 = new Start();
      
       
       
       
       }
      
       
    
}